// script.js
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('year').textContent = new Date().getFullYear();
  const navToggle = document.getElementById('nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  navToggle.addEventListener('click', () => {
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    mainNav.style.display = expanded ? 'none' : 'flex';
  });

  const events = [
    {title: "Freebustamive Pre-Birthday Bash", date: "Nov 19, 2025", time: "5:00 PM - 9:00 PM", venue: "Martinis Restaurant & Lounge, Fort Washington, MD", desc: "URB performing live. Free admission. DJ Boski da Entertainer. Food & drink promos."},
    {title: "GoGo & Gaming Experience", date: "Aug 15, 2025", time: "8:00 PM - 11:00 PM", venue: "Martinis Restaurant", desc: "First-ever GoGo music and gaming experience. Live URB set."},
    {title: "Black Frederick Festival", date: "TBD", time: "All Day", venue: "Frederick, MD", desc: "Festival appearance — URB. Check social for exact schedule."}
  ];

  const grid = document.getElementById('events-grid');
  events.forEach(ev => {
    const card = document.createElement('article');
    card.className = 'card event-card';
    card.innerHTML = `
      <h4>${ev.title}</h4>
      <div class="event-meta">${ev.date} • ${ev.time}</div>
      <div class="event-meta">${ev.venue}</div>
      <p class="event-desc">${ev.desc}</p>
      <div style="margin-top:10px"><a class="btn" href="#contact">Request Info</a></div>
    `;
    grid.appendChild(card);
  });

  const form = document.getElementById('contact-form');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();
    const subject = encodeURIComponent(`Booking/Contact from website — ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`);
    window.location.href = `mailto:jacksonjoe071@gmail.com?subject=${subject}&body=${body}`;
  });

  document.getElementById('mailto-fallback').addEventListener('click', () => {
    const name = document.getElementById('name').value.trim() || 'Name';
    const body = encodeURIComponent('Message here...');
    window.location.href = `mailto:jacksonjoe071@gmail.com?subject=${encodeURIComponent('Booking Inquiry - ' + name)}&body=${body}`;
  });
});
